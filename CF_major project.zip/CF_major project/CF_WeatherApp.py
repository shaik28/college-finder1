from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from PIL import Image,ImageTk
import requests
blue='#0066cc'

class WeatherApp:
    global url,apiKey
    apiKey = '6c9de6064dc72c25be9655293252b5cd'
    url='http://api.openweathermap.org/data/2.5/weather?q={}&appid={}'
    


    def __init__(self,root):
        self.root=root
        self.root.title("CheckWeather")
        self.root.geometry("380x450+550+150")
        self.root['bg']='red'
        # self.txt=Label(text='CheckWeather by CF',font=('rockwell bold',16),bg='red',fg='white')
        # self.txt.pack(pady=20)

        cityText=StringVar()
        cityEntry=ttk.Entry(root,text=cityText,font=('arial bold',30),style="EntryStyle.TEntry",justify='center',width=20)
        cityEntry.pack(pady=0)
        cityEntry.focus()

        def check_weather(city):
            result=requests.get(url.format(city,apiKey))
            if result:
                json=result.json()
                #city,country,temp_celsius,temp_farenheit,icon,weather
                city=json['name']  #0
                country=json['sys']['country'] #1
                temp_kelvin=json['main']['temp'] 
                temp_Celsius=temp_kelvin - 273.15  #2
                temp_farenheit=temp_Celsius*(9/5)+32  #3
                icon=json['weather'][0]['icon']  #4
                weather=json['weather'][0]['main']  #5
                final=(city,country,temp_kelvin,temp_Celsius,temp_farenheit,icon,weather)
                return final
            else:
                return None
        
        def searched_for(root):
            city=cityText.get()
            weather=check_weather(city)
            if weather:
                locationLabel['text']=f"{weather[0]}, {weather[1]}"
                temperatureLabel['text']=f"{weather[2]:.2f} °C,{weather[3]:.2f} °F"
                WeatherLabel['text']=f'{weather[5]}'
                img["file"]=f'img\\{weather[4]}.png'
                introLabel.destroy()
            else:
                messagebox.showerror('ERROR',f"could't find the city name '{city}':(-")
            print(f"searched for: {city}")
        

        def press():
            introLabel.destroy()
            searched_for(root)




        searchButton=Button(root,text='Press Enter \n/\nSearchWeather',font=('rockwell bold',16),width=20,height=4,bg=blue,fg='white',command=press)
        searchButton.pack(pady=20)

        cityEntry.bind('<Button>',searched_for)

        locationLabel=Label(root,text='',bg='red',font=('rockwell bold',30))
        locationLabel.pack()

        introLabel= Label(root,text='search by - state/city/country',font=("rockwell bold",16),bg='red',fg='white')
        introLabel.pack()

        img = PhotoImage(file='')
        image=Label(root,image=img,bg='red',fg='white')
        image.pack()

        temperatureLabel=Label(root,text='',font=('rockwell bold',21),bg='red',fg='white')
        temperatureLabel.pack()

        WeatherLabel=Label(root,text='',font=('rockwell bold',21),bg='red',fg='white')
        WeatherLabel.pack()



    def startWeather():         
        root=Toplevel()
        WeatherApp(root)
        root.mainloop()